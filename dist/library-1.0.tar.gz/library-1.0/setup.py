from setuptools import setup

setup(
    name='library',
    version='1.0',
    description='Moja biblioteka',
    url='git@github.com:rfschubert/ptolemaios-sdk-package.git',
    author='Karolina',
    author_email='kmatusiak2@st.swps.edu.pl',
    license='unlicense',
    packages=['library'],
    zip_safe=False
)
