def dodawanie (x, y):
    x = int(input("Podaj cyfre:" ))
    y = int(input("Podaj cyfre:" ))
    math = (x + y)
    return math